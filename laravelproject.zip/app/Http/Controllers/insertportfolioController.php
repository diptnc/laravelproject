<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class insertportfolioController extends Controller
{
    //
}
