<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php foreach ($portfolio_page as $pp) {
 
   
    $pp_image_name_raw = $pp->image_name;
    $pp_image_name = pathinfo($pp_image_name_raw, PATHINFO_FILENAME);
    $pp_image_type = $pp->image_type;
    } ?>

    <?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>

    <?php echo JsonLd::generate(); ?>

    <link href="<?php echo e(asset('assets/css/singleportfoliopage.min.css')); ?>" rel="stylesheet">

</head>
<?php $__env->startComponent('components.header', ['social_links_raw' => $social_links_raw]); ?>
<?php if (isset($__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa)): ?>
<?php $component = $__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa; ?>
<?php unset($__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<body class="html">

<section class="main">



    <div class="container ">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center text-sm-left text-md-left text-lg-left text-xl-left t1"><?php echo e($pp->title); ?></h1>
                <p  class="text-center text-sm-left text-md-left text-lg-left text-xl-left t2">Date : <?php echo e($pp->date); ?></p>
                <p  class="text-center text-sm-left text-md-left text-lg-left text-xl-left t4 <?php echo e($pp->style); ?>">
                    <?php echo e($pp->category); ?>

                    
                </p>
                <div class="text-center text-sm-left text-md-left text-lg-left text-xl-left ">
                    <picture>
                        <source class="lazy" srcset=<?php echo e(asset("assets/images/portfolio/$pp_image_name.webp")); ?>

                            type="image/webp" alt="<?php echo e($pp_image_name); ?>">
                        <source class="lazy" srcset=<?php echo e(asset("assets/images/portfolio/$pp_image_name.$pp_image_type")); ?>

                            type="image/<?php echo e($pp_image_type); ?>" alt="<?php echo e($pp_image_name); ?>">
                        <img class="lazy" src=<?php echo e(asset("assets/images/portfolio/$pp_image_name.$pp_image_type")); ?>

                            alt="<?php echo e($pp_image_name); ?>">

                    </picture>

                </div>
            </div>
            <div class="col-md-12">
                <h1 class="text-center text-sm-left text-md-left text-lg-left text-xl-left t3"><?php echo e($pp->title); ?></h1>
                <p class="text-center text-sm-left text-md-left text-lg-left text-xl-left t5"><?php echo $pp->description; ?></p>
                <div class="text-center text-sm-left text-md-left text-lg-left text-xl-left">
                    
                </div>
            </div>
        </div>
    </div>



</section>



    <?php $__env->startComponent('components.footer', [
        'social_links_raw' => $social_links_raw,
        ]); ?>

    <?php if (isset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b)): ?>
<?php $component = $__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b; ?>
<?php unset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



    <?php $__env->startComponent('components.scriptsingleportfolio'); ?>
    <?php if (isset($__componentOriginal2272fd3a6a57db25137db20535fe678d698730a3)): ?>
<?php $component = $__componentOriginal2272fd3a6a57db25137db20535fe678d698730a3; ?>
<?php unset($__componentOriginal2272fd3a6a57db25137db20535fe678d698730a3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</body>

</html>
<?php /**PATH D:\Webserver\test\diptanuchakraborty.in\resources\views/components/portfolio/singleitem.blade.php ENDPATH**/ ?>