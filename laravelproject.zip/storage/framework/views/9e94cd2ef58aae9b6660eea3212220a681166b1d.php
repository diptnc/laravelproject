<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Portfolio | Diptanu chakraborty</title>
    <link href="<?php echo e(asset('assets/css/portfolio.min.css')); ?>" rel="stylesheet">
    
</head>
<?php $__env->startComponent('components.header',['social_links_raw'=>$social_links_raw]); ?>
<?php if (isset($__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa)): ?>
<?php $component = $__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa; ?>
<?php unset($__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<body class="html" >



    <?php $__env->startComponent('components.portfolio.section1',['portfolio_raw' => $portfolio_raw,
    'pg_portfolio_items'=>$pg_portfolio_items]); ?>
    <?php if (isset($__componentOriginal88081818ee38f98e2bed4124405e47b488a9903e)): ?>
<?php $component = $__componentOriginal88081818ee38f98e2bed4124405e47b488a9903e; ?>
<?php unset($__componentOriginal88081818ee38f98e2bed4124405e47b488a9903e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>









    <?php $__env->startComponent('components.footer',[
    'social_links_raw'=>$social_links_raw
]); ?>
    
<?php if (isset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b)): ?>
<?php $component = $__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b; ?>
<?php unset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->startComponent('components.scriptportfoliopage'); ?>
<?php if (isset($__componentOriginal1368805dd5f841027e9154caa39804f58d7704c2)): ?>
<?php $component = $__componentOriginal1368805dd5f841027e9154caa39804f58d7704c2; ?>
<?php unset($__componentOriginal1368805dd5f841027e9154caa39804f58d7704c2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</body>
</html>
<?php /**PATH D:\Webserver\test\diptanuchakraborty.in\resources\views\portfoliopage.blade.php ENDPATH**/ ?>