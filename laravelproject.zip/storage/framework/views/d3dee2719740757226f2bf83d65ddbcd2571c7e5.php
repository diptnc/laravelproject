<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Diptanu chakraborty</title>
    <link href="<?php echo e(asset('assets/css/home.min.css')); ?>" rel="stylesheet">
</head>
<?php $__env->startComponent('components.splash-screen'); ?>
<?php if (isset($__componentOriginal9f6f70a91535af306ac06f65a5c55ca9e3f55bf7)): ?>
<?php $component = $__componentOriginal9f6f70a91535af306ac06f65a5c55ca9e3f55bf7; ?>
<?php unset($__componentOriginal9f6f70a91535af306ac06f65a5c55ca9e3f55bf7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->startComponent('components.header',['social_links_raw'=>$social_links_raw]); ?>
<?php if (isset($__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa)): ?>
<?php $component = $__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa; ?>
<?php unset($__componentOriginal18051af5e3d1ed028dc5239cc3437b52a8c6fefa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<body class="html" >


<?php $__env->startComponent('components.section1',['social_links_raw'=>$social_links_raw]); ?>
<?php if (isset($__componentOriginalee6df01e205613ac634c1a28fa58ab6de3c6f266)): ?>
<?php $component = $__componentOriginalee6df01e205613ac634c1a28fa58ab6de3c6f266; ?>
<?php unset($__componentOriginalee6df01e205613ac634c1a28fa58ab6de3c6f266); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('components.section2',['about_raw'=>$about_raw]); ?>
<?php if (isset($__componentOriginal13b12319c89264686b022c769ce60c1543b6e446)): ?>
<?php $component = $__componentOriginal13b12319c89264686b022c769ce60c1543b6e446; ?>
<?php unset($__componentOriginal13b12319c89264686b022c769ce60c1543b6e446); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


     <?php if (isset($component)) { $__componentOriginal244cb177926e73bba3cf5de9c24a85fc5b0a2241 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Section3::class, []); ?>
<?php $component->withName('section3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal244cb177926e73bba3cf5de9c24a85fc5b0a2241)): ?>
<?php $component = $__componentOriginal244cb177926e73bba3cf5de9c24a85fc5b0a2241; ?>
<?php unset($__componentOriginal244cb177926e73bba3cf5de9c24a85fc5b0a2241); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

     <?php if (isset($component)) { $__componentOriginal45d37d1e06b882a36a4b37cd55df9b8eb2224251 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Section4::class, []); ?>
<?php $component->withName('section4'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal45d37d1e06b882a36a4b37cd55df9b8eb2224251)): ?>
<?php $component = $__componentOriginal45d37d1e06b882a36a4b37cd55df9b8eb2224251; ?>
<?php unset($__componentOriginal45d37d1e06b882a36a4b37cd55df9b8eb2224251); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 
    <?php $__env->startComponent('components.section5',[
        'portfolio_raw'=>$portfolio_raw,
        'portfolio_recent_raw'=>$portfolio_recent_raw,
        'achivements'=>$achivements
        ]); ?>
    <?php if (isset($__componentOriginal2e907c1e32689a0f328ad407ce5665034a3ddd62)): ?>
<?php $component = $__componentOriginal2e907c1e32689a0f328ad407ce5665034a3ddd62; ?>
<?php unset($__componentOriginal2e907c1e32689a0f328ad407ce5665034a3ddd62); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
     <?php if (isset($component)) { $__componentOriginal9f5365a6e5a1b353cd6b784572b3c976db0104c8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Wcu::class, []); ?>
<?php $component->withName('wcu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9f5365a6e5a1b353cd6b784572b3c976db0104c8)): ?>
<?php $component = $__componentOriginal9f5365a6e5a1b353cd6b784572b3c976db0104c8; ?>
<?php unset($__componentOriginal9f5365a6e5a1b353cd6b784572b3c976db0104c8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalcf7dfc965ec2c10ac440d2e58d5894395e85924d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Section6::class, []); ?>
<?php $component->withName('section6'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf7dfc965ec2c10ac440d2e58d5894395e85924d)): ?>
<?php $component = $__componentOriginalcf7dfc965ec2c10ac440d2e58d5894395e85924d; ?>
<?php unset($__componentOriginalcf7dfc965ec2c10ac440d2e58d5894395e85924d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 
<?php $__env->startComponent('components.section7'); ?>
    
<?php if (isset($__componentOriginal9aabafafbd336bf5d8e0cceb8a15a29f9a2f9e0b)): ?>
<?php $component = $__componentOriginal9aabafafbd336bf5d8e0cceb8a15a29f9a2f9e0b; ?>
<?php unset($__componentOriginal9aabafafbd336bf5d8e0cceb8a15a29f9a2f9e0b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    
<?php $__env->startComponent('components.footer',[
    'social_links_raw'=>$social_links_raw
]); ?>
    
<?php if (isset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b)): ?>
<?php $component = $__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b; ?>
<?php unset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.scripthome'); ?>
<?php if (isset($__componentOriginal33498079ce40d2d0b42a7a0f47ae541d23597f27)): ?>
<?php $component = $__componentOriginal33498079ce40d2d0b42a7a0f47ae541d23597f27; ?>
<?php unset($__componentOriginal33498079ce40d2d0b42a7a0f47ae541d23597f27); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

</body>
</html>
<?php /**PATH D:\Webserver\test\diptanuchakraborty.in\resources\views\home.blade.php ENDPATH**/ ?>